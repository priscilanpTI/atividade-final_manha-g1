package modelo;

public class Livro Acervo {
    String autor;
    int paginas;


    public void exibirDetalhes() {
        exibirInfo();
        System.out.println("Autor: " + autor);
        System.out.println("Páginas: " + paginas);
    }

    public static void main(String[] args) {
        Livro livro = new Livro("Java Básico", 2020, "João Silva", 300)
        livro.exibirDetalhes();
    }
}
